public interface Ecology {
    public String getHabitat(); // Returns out the animal habitat.
}
