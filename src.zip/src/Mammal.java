

public abstract class Mammal implements Ecology,Animal {
    // Implement the eat() method within Mammal to print out "Eats like a mammal."
    private String name;
    private String habitat;
    private String specie;

    public Mammal(){}
    public void eat(){
        System.out.println("Eats like a mammal.");
    }
    public abstract void sound();
    public abstract String getHabitat();
//    public String getName(); // Returns out the animal name.
//    public String getSpecies(); // Returns out the species name
//    public void eat(); // Prints out an eating action.
//    public void sound(); //  Print the sound the animal makes.
//    public String getHabitat();

    public static Animal get(String name, String species){
        if(species.equalsIgnoreCase("lion")){
            return new Lion(name);
        }else if(species.equalsIgnoreCase("elephant")) {
            return new Elephant(name);
        }
        System.out.println("Species invalid");
        return null;
    }


}

class Elephant extends Mammal{
    public Elephant(String name){
        habitat = "Savana";
    }
    public void sound(){
        System.out.println("Trumpets");
    }
    public String getHabitat(){
        return habitat;
    }

}

class Lion extends Mammal{
    public Lion(String name1){
        name = name1;
        habitat = "Savana";
    }
    public void sound(){
        System.out.println("Roars");
    }
    public String getHabitat(){
        return habitat;
    }
}


